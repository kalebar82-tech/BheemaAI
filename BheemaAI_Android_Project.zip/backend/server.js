import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(helmet());
app.use(cors()); // In production, restrict this to your own domains.
app.use(express.json({ limit: "1mb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 30 }));

app.get("/health", (_req, res) => res.json({ ok: true, app: "Bheema AI" }));

app.post("/api/chat", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "AI service is not configured" });
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 20)
      return res.status(400).json({ error: "messages must be an array of 1–20 items" });

    const safeMessages = messages.map(m => {
      if (!["user", "assistant"].includes(m.role) || typeof m.content !== "string")
        throw new Error("Invalid message format");
      return { role: m.role, content: m.content.slice(0, 8000) };
    });

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: "You are Bheema AI, a helpful, honest and capable assistant. Reply in the language used by the user, especially Urdu or English. Be clear and useful. Never claim to have performed actions you did not perform.",
        input: safeMessages.map(m => ({ role: m.role, content: [{ type: "input_text", text: m.content }] }))
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("AI provider error", response.status, data);
      return res.status(502).json({ error: "AI provider request failed" });
    }
    const reply = (data.output || []).flatMap(item => item.content || [])
      .filter(part => part.type === "output_text").map(part => part.text).join("\\n").trim();
    res.json({ reply: reply || "معذرت، اس وقت جواب تیار نہیں ہو سکا۔" });
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: "Request could not be processed" });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Bheema AI backend listening on ${port}`));
