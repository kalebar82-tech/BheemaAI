package com.bheema.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(val text: String, val user: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BheemaApp() }
    }
}

private val ink = Color(0xFF10101B)
private val panel = Color(0xFF1B1A2A)
private val violet = Color(0xFF9875FF)
private val muted = Color(0xFFB9B5C9)

@Composable
fun BheemaApp() {
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("اردو + English") }
    var error by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(ChatMessage("السلام علیکم! میں Bheema AI ہوں۔ آپ مجھ سے اردو یا English میں کچھ بھی پوچھ سکتے ہیں۔", false)) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = violet, background = ink, surface = panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(ink).statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("BHEEMA AI", color = violet, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text("Your intelligent assistant", color = muted, fontSize = 12.sp)
                }
                TextButton(onClick = { language = if (language == "اردو + English") "English" else "اردو + English" }) {
                    Text(language, color = Color.White)
                }
                IconButton(onClick = {
                    messages.clear()
                    messages.add(ChatMessage("نئی چیٹ شروع ہوگئی۔ کیسے مدد کروں؟", false))
                    error = ""
                }) { Icon(Icons.Default.Add, contentDescription = "New chat", tint = Color.White) }
            }
            HorizontalDivider(color = Color(0xFF343147))
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement =
                        if (msg.user) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (msg.user) Color(0xFF49377A) else panel,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Text(msg.text, Modifier.padding(14.dp), color = Color.White, fontSize = 15.sp)
                        }
                    }
                }
                if (busy) item { Text("Bheema سوچ رہا ہے…", color = violet, fontSize = 13.sp) }
                if (error.isNotBlank()) item { Text(error, color = Color(0xFFFF8B8B), fontSize = 12.sp) }
            }
            Row(
                Modifier.fillMaxWidth().padding(12.dp).background(panel, RoundedCornerShape(24.dp)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 10.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                    decorationBox = { inner ->
                        if (input.isEmpty()) Text("پیغام لکھیں… / Ask anything", color = muted)
                        inner()
                    }
                )
                IconButton(
                    enabled = input.isNotBlank() && !busy,
                    onClick = {
                        val prompt = input.trim()
                        input = ""
                        messages.add(ChatMessage(prompt, true))
                        error = ""
                        busy = true
                        scope.launch {
                            try {
                                val answer = withContext(Dispatchers.IO) { askBheema(prompt, messages.dropLast(1)) }
                                messages.add(ChatMessage(answer, false))
                            } catch (e: Exception) {
                                error = "کنکشن نہیں ہو سکا: ${e.message ?: "براہ کرم سرور چیک کریں"}"
                            } finally { busy = false }
                        }
                    }
                ) { Icon(Icons.Default.Send, contentDescription = "Send", tint = violet) }
            }
            Text("AI can make mistakes. اہم معلومات کی تصدیق کریں۔",
                Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp),
                color = muted, fontSize = 10.sp)
        }
    }
}

private fun askBheema(prompt: String, history: List<ChatMessage>): String {
    val base = BuildConfig.API_BASE_URL
    require(!base.contains("YOUR_BACKEND_DOMAIN")) {
        "app/build.gradle.kts میں API_BASE_URL کو اپنے HTTPS backend URL سے تبدیل کریں"
    }
    val arr = JSONArray()
    history.takeLast(16).forEach { m ->
        arr.put(JSONObject().put("role", if (m.user) "user" else "assistant").put("content", m.text))
    }
    arr.put(JSONObject().put("role", "user").put("content", prompt))
    val body = JSONObject().put("messages", arr).toString()
        .toRequestBody("application/json; charset=utf-8".toMediaType())
    val client = OkHttpClient.Builder().connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS).build()
    val req = Request.Builder().url(base.trimEnd('/') + "/api/chat").post(body).build()
    client.newCall(req).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw Exception("Server ${response.code}: $raw")
        val json = JSONObject(raw)
        return json.optString("reply").ifBlank { "جواب موصول نہیں ہوا۔ دوبارہ کوشش کریں۔" }
    }
}
