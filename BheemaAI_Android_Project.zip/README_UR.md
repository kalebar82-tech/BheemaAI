# BHEEMA AI — Android + real AI backend

یہ ایک مکمل ابتدائی Android Studio پروجیکٹ ہے: Jetpack Compose چیٹ ایپ اور Node.js backend۔ AI جواب OpenAI API سے آتا ہے۔ API key صرف backend پر رکھی جاتی ہے، APK میں نہیں۔

## 1) آپ کو کیا درکار ہوگا
- Android Studio (JDK 17 کے ساتھ)
- Node.js 20 یا نیا
- ایک OpenAI API key اور API billing/credits
- HTTPS پر چلنے والا backend hosting (مثلاً اپنی VPS یا مناسب Node hosting)

## 2) Backend چلائیں
```bash
cd backend
cp .env.example .env
```
`.env` میں `OPENAI_API_KEY` اپنی خفیہ key سے بدلیں۔ پھر:
```bash
npm install
npm start
```
`https://YOUR_DOMAIN/health` پر `{"ok":true,...}` آنا چاہیے۔ Production میں HTTPS لازمی رکھیں، `.env` یا key کسی کے ساتھ شیئر نہ کریں۔

## 3) Android ایپ کو backend سے جوڑیں
`app/build.gradle.kts` میں:
```kotlin
buildConfigField("String", "API_BASE_URL", "\\"https://YOUR_BACKEND_DOMAIN/\\"")
```
`YOUR_BACKEND_DOMAIN` کو اپنے اصل HTTPS domain سے بدلیں، مثال:
`https://api.example.com/`

پھر Android Studio میں اس فولڈر کو Open کریں، Gradle Sync کریں اور Run دبائیں۔

## 4) APK بنائیں
Android Studio:
**Build > Generate App Bundles or APKs > Build APK(s)**

Play Store کے لیے عموماً signed Android App Bundle (AAB) درکار ہوتا ہے:
**Build > Generate Signed Bundle / APK > Android App Bundle**
اپنی signing key محفوظ رکھیں؛ اسے ضائع نہ کریں۔

## 5) اہم حدود / اگلے کام
یہ ورژن حقیقی AI چیٹ، اردو/انگلش، نئی چیٹ اور موجودہ گفتگو کا context فراہم کرتا ہے۔ اس میں ابھی login، cloud-synced chat history، image upload/generation، voice, subscriptions, moderation dashboard اور Play Store privacy/data-safety declarations شامل نہیں ہیں۔ انہیں production launch سے پہلے الگ سے بنانا اور ٹیسٹ کرنا ہوگا۔

Backend میں rate limiting موجود ہے مگر public launch سے پہلے user authentication، abuse monitoring، usage quotas، stricter CORS اور hosting secrets ضرور شامل کریں۔ API استعمال کی قیمت آپ کے provider account سے کٹے گی؛ یہ ChatGPT subscription میں شامل نہیں ہوتی۔
